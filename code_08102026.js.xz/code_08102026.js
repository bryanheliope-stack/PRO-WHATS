import pino from 'pino'
import http from 'node:http'
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } from '@whiskeysockets/baileys'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 📂 Pastas
const TEMP_DIR = path.join(__dirname, 'temp')
const KNOWLEDGE_DIR = path.join(__dirname, 'knowledge')
const AUTH_DIR = path.join(__dirname, 'auth')
;[TEMP_DIR, KNOWLEDGE_DIR, AUTH_DIR].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
})

// ==========================================
// 🏓 SISTEMA DE PING
// ==========================================
const PING_SYSTEM = {
  url: process.env.RENDER_EXTERNAL_URL || process.env.PING_URL || '',
  interval: parseInt(process.env.PING_INTERVAL_MINUTES || '5') * 60 * 1000,
  timer: null,

  async ping() {
    if (!this.url) return false
    try {
      const res = await fetch(`${this.url}/ping`, { signal: AbortSignal.timeout(15000) })
      console.log(`🏓 Ping: ${res.ok ? '✅ ONLINE' : '⚠️ OK'}`)
      return true
    } catch (err) {
      console.warn(`🏓 Ping falhou: ${err.message}`)
      return false
    }
  },

  iniciar() {
    if (!this.url) return
    this.ping()
    this.timer = setInterval(() => this.ping(), this.interval)
  }
}

// ==========================================
// 🖼️ SISTEMA DE BUSCA DE IMAGENS NA INTERNET
// ==========================================
const BuscaImagens = {
  apiKey: process.env.PEXELS_API_KEY || '',
  cache: new Map(),
  limitePorBusca: 3,

  async buscar(termo, limite = 1) {
    if (!this.apiKey) {
      console.log('ℹ️ PEXELS_API_KEY não configurada — busca de imagens desativada')
      return []
    }

    const cacheKey = termo.toLowerCase()
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey)
    }

    try {
      const query = encodeURIComponent(`${termo} screenshot emulator game`)
      const res = await fetch(
        `https://api.pexels.com/v1/search?query=${query}&per_page=${this.limitePorBusca}&orientation=landscape`,
        {
          headers: { Authorization: this.apiKey },
          signal: AbortSignal.timeout(8000)
        }
      )

      if (!res.ok) throw new Error(`API Pexels: ${res.status}`)
      const dados = await res.json()
      
      const imagens = dados.photos?.map(foto => ({
        id: foto.id,
        url: foto.src?.medium || foto.src?.large,
        urlOriginal: foto.src?.original,
        autor: foto.photographer,
        pagina: foto.url,
        alt: foto.alt || termo
      })) || []

      this.cache.set(cacheKey, imagens)
      if (this.cache.size > 100) this.cache.clear() // Limpa cache periodicamente
      
      console.log(`🖼️ Encontradas ${imagens.length} imagens para: ${termo}`)
      return imagens.slice(0, limite)
    } catch (err) {
      console.warn(`⚠️ Erro na busca de imagens: ${err.message}`)
      return []
    }
  },

  // Formata a legenda com link da imagem
  formatarLink(imagem, termo) {
    if (!imagem) return ''
    return `\n\n📸 Foto de ${imagem.autor} no Pexels\n🔗 ${imagem.pagina}`
  }
}

// ==========================================
// 🧠 SISTEMA DE RESPOSTAS INTELIGENTES
// ==========================================
const normalizar = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')

const STOPWORDS = new Set(['de','do','da','no','na','em','um','uma','os','as','ou','se','eu','me','meu','minha','pra','para','com','que','qual','como','sobre','é','a','o','que','quais','quem','onde','quando','por','porque'])

const CONVERSA_NATURAL = {
  saudações: {
    oi: 'Oi! 😊 Tudo bem? Sou seu assistente de emuladores! É só perguntar que eu te ajudo!',
    olá: 'Olá! 👋 Como está? Precisa de ajuda com algum emulador? Estou aqui!',
    'bom dia': 'Bom dia! ☀️ Bora configurar aquele emulador? É só mandar a pergunta!',
    'boa tarde': 'Boa tarde! 😜 Tudo bem? Qual é a dúvida de hoje?',
    'boa noite': 'Boa noite! 🌙 Hora de jogar? Me pergunta qualquer coisa!'
  },
  despedidas: {
    valeu: 'De nada! 😎 Bora jogar! Qualquer coisa é só chamar! 🎮',
    obrigado: 'Que isso! 😊 Sempre às ordens! Divirta-se! 🎮',
    obrigada: 'De nada! 😘 Qualquer dúvida, é só falar!',
    vlw: '✌️ Bora jogar! Até mais!',
    tchau: '👋 Até mais! Bom jogo!'
  },
  apresentacao: {
    'quem é você': 'Sou seu assistente de emuladores! 🎮 Ajudo com tudo sobre jogos no celular e PC — Winlator, GameHub, Eden, PPSSPP, configurações, DXVK, drivers e muito mais. Agora também busco imagens pra você! É só perguntar naturalmente!',
    'o que você faz': 'Te ajudo com emuladores! 🎮 Qual usar, como configurar, melhorar performance, resolver problemas... e ainda mostro imagens! É só perguntar!',
    'ajuda': 'Claro! 😊 Você pode me perguntar coisas como:\n• "Como configurar o Winlator?"\n• "Mostre-me o Eden Emulator"\n• "Qual DXVK usar no GameHub?"\n• "Eden está lento, o que fazer?"\n\nTambém tenho comandos:\n!ajuda — lista de comandos\n!ping — verifica se estou online\n!lista — tópicos que conheço\n!imagem [termo] — Busca uma imagem na internet'
  }
}

// ==========================================
// 🧠 MOTOR DE RESPOSTAS INTELIGENTES
// ==========================================
const GeradorResposta = {
  // Palavras-chave que indicam que o usuário quer ver uma imagem
  termosImagem: new Set(['mostre', 'imagem', 'foto', 'print', 'captura', 'como é', 'interface', 'tela', 'visual']),

  querImagem(pergunta) {
    const p = normalizar(pergunta)
    for (const termo of this.termosImagem) {
      if (p.includes(termo)) return true
    }
    return false
  },

  // Gera uma resposta natural a partir de um item da base
  gerar(pergunta, item, chave) {
    const perguntaNorm = normalizar(pergunta)
    
    let resposta = ''
    if (item.titulo) {
      resposta += `${item.titulo}\n\n`
    }

    if (item.descricao) {
      resposta += `${item.descricao}\n\n`
    }

    if (item.o_que_e) {
      resposta += `ℹ️ ${item.o_que_e}\n\n`
    }

    if (item.requisitos) {
      resposta += `📋 Requisitos: ${item.requisitos}\n\n`
    }

    if (item.resolucao) {
      resposta += `🖥️ Resolução ideal:\n${item.resolucao}\n\n`
    }

    if (item.dicas) {
      if (Array.isArray(item.dicas)) {
        resposta += `💡 Dicas importantes:\n${item.dicas.join('\n')}\n\n`
      } else {
        resposta += `💡 ${item.dicas}\n\n`
      }
    }

    if (item.lista) {
      resposta += `${item.lista.join('\n')}\n\n`
    }

    if (item.versoes && Array.isArray(item.versoes)) {
      resposta += `📦 Versões recomendadas:\n${item.versoes.join('\n')}\n\n`
    }

    if (item.modos && !Array.isArray(item.modos)) {
      resposta += `🔧 Modos disponíveis:\n`
      for (const [nome, desc] of Object.entries(item.modos)) {
        resposta += `• ${nome}: ${desc}\n`
      }
      resposta += '\n'
    }

    if (item.tela_preta || item.jogo_não_abre || item.lento) {
      if (item.tela_preta) {
        resposta += `🖤 Tela preta? Tente isso:\n${item.tela_preta.join('\n')}\n\n`
      }
      if (item.jogo_não_abre) {
        resposta += `❌ Jogo não abre? Tente:\n${item.jogo_não_abre.join('\n')}\n\n`
      }
      if (item.lento) {
        resposta += `🐌 Está lento? Tente:\n${item.lento.join('\n')}\n\n`
      }
      if (item.sem_som) {
        resposta += `🔇 Sem som?\n${item.sem_som.join('\n')}\n`
      }
    }

    if (item.dica) {
      resposta += `💡 ${item.dica}\n`
    }

    if (item.observacao) {
      resposta += `ℹ️ ${item.observacao}\n`
    }

    if (item.site) {
      resposta += `🌐 Site oficial: ${item.site}\n`
    }

    if (!resposta || resposta.length < 10) {
      resposta = this.fallback(chave, item)
    }

    return resposta.trim()
  },

  semResposta(pergunta) {
    return `🤔 Entendi sua pergunta: "${pergunta}"\n\nAinda não tenho uma resposta exata sobre isso, mas posso ajudar com:\n\n🪟 Winlator / GameHub — rodar jogos de PC no celular\n🔷 DXVK, Wine, Proton, Box64 — configurações\n🎮 Eden (Switch), PPSSPP (PSP), Dolphin (GameCube/Wii)\n📱 Emuladores para celular e PC\n🖼️ Busque imagens com: "imagem winlator" ou "mostre o Eden"\n\nTente perguntar de forma mais simples! 😊`
  },

  fallback(chave, item) {
    if (typeof item === 'string') return item
    return JSON.stringify(item, null, 2).slice(0, 500)
  }
}

// ==========================================
// 📚 BASE DE CONHECIMENTO COMPLETA
// ==========================================
const EmuladorBase = {
  dados: new Map(),
  aliases: new Map(),
  arquivo: path.join(KNOWLEDGE_DIR, 'emulador_base.json'),

  carregar() {
    this.inicializarBaseCompleta()
    try {
      if (fs.existsSync(this.arquivo)) {
        const salvos = JSON.parse(fs.readFileSync(this.arquivo, 'utf8'))
        let custom = 0
        for (const [chave, valor] of Object.entries(salvos)) {
          if (valor && valor.custom) {
            this.dados.set(chave.toLowerCase(), valor)
            custom++
          }
        }
        console.log(`🎮 Base carregada: ${this.dados.size} verbetes (${custom} ensinados por você)`)
      }
    } catch (err) {
      console.warn(`⚠️ Erro ao ler base salva: ${err.message}`)
    }
    this.salvar()
  },

  inicializarBaseCompleta() {
    const base = {
      // ===== WINLATOR =====
      'winlator': {
        titulo: '🪟 Winlator — Jogos de Windows no Celular!',
        plataforma: 'Android',
        sistema: 'Windows (PC)',
        descricao: 'Winlator é um app incrível que permite rodar jogos e programas de Windows diretamente no seu celular Android. Ele combina o Box64, que traduz os comandos do PC para o celular, com o Wine, que faz a compatibilidade com os programas.',
        requisitos: 'Android 10 ou superior | Idealmente um celular com Snapdragon 720G ou melhor | Pelo menos 4GB de RAM',
        resolucao: '📱 Celular mais simples: 800×600\n📱 Intermediário: 960×544\n📱 Celular bom: 1280×720',
        dicas: [
          '🔹 Crie um container diferente para cada jogo',
          '🔹 Se o jogo estiver lento, abaixe a resolução primeiro',
          '🔹 Não coloque resolução maior que a tela do seu celular'
        ],
        site: 'winlator.dev',
        termoBuscaImagem: 'Winlator Android app'
      },

      'winlator configuração': {
        titulo: '⚙️ Melhores Configurações para o Winlator',
        resolucao: '📱 Celular básico: 800×600\n📱 Intermediário: 960×544\n📱 Celular bom: 1280×720',
        memoria: 'Se tem 8GB de RAM → coloque 4GB. Se tem 6GB → coloque 2 a 3GB.',
        wow64: 'Ativado para jogos antigos de 32 bits. Desativado para jogos mais novos de 64 bits.',
        msync_esync: 'Sempre deixe ativado! Reduz bastante o uso do processador.',
        audio: 'Use ALSA para menor latência. Se não sair som nenhum, troque para PulseAudio.',
        dica: 'Cada jogo pode gostar de uma configuração diferente. Mude uma coisa de cada vez!'
      },

      'gamehub': {
        titulo: '🎮 GameHub — Novo Emulador de Windows para Celular',
        plataforma: 'Android',
        sistema: 'Windows (PC)',
        descricao: 'GameHub é um novo aplicativo da mesma equipe do Winlator. Tem uma interface mais bonita e fácil de usar, além de usar o Proton em vez do Wine.',
        requisitos: 'Android 10+ | Idealmente Snapdragon 8 Gen 1 ou melhor | Mínimo de 6GB de RAM',
        vantagens: [
          '✅ Interface mais amigável',
          '✅ Organiza seus jogos em biblioteca',
          '✅ Usa Proton — mais jogos funcionam de primeira',
          '✅ Mais fácil para iniciantes'
        ],
        site: 'winlator.dev/gamehub',
        termoBuscaImagem: 'GameHub Android emulator'
      },

      'eden': {
        titulo: '🔵 Eden — Emulador de Switch para Celular',
        plataforma: 'Android',
        sistema: 'Nintendo Switch',
        descricao: 'Eden é atualmente o melhor emulador de Switch para Android. É gratuito e de código aberto, permitindo rodar muitos jogos de Switch no celular!',
        requisitos: 'Android com Vulkan 1.1+ | Snapdragon 8 Gen 1 ou melhor ideal | 8GB de RAM mínimo',
        precisa: 'prod.keys + firmware extraídos do SEU próprio console Nintendo Switch.',
        dicas: [
          '🔹 Só existe Vulkan no Android',
          '🔹 Use o baixador de driver embutido',
          '🔹 Comece com jogos mais leves'
        ],
        site: 'eden-emu.dev',
        termoBuscaImagem: 'Eden Emulator Nintendo Switch Android'
      },

      'ppsspp': {
        titulo: '🎮 PPSSPP — O Melhor Emulador de PSP',
        plataforma: 'Android e PC',
        sistema: 'PlayStation Portable (PSP)',
        descricao: 'PPSSPP é simplesmente o melhor emulador de PSP que existe! Roda praticamente todos os jogos e é super leve — funciona bem até em celulares mais simples.',
        requisitos: 'Celular básico já roda bem! Snapdragon 660 já dá pra jogar em resolução 2x.',
        resolucao: '📱 Celular simples: 1x (480p)\n📱 Intermediário: 2x (960p)\n📱 Celular bom: 3x a 5x',
        site: 'ppsspp.org',
        termoBuscaImagem: 'PPSSPP emulator PSP Android'
      },

      'dxvk': {
        titulo: '🔷 DXVK — Guia Completo',
        o_que_e: 'DXVK é uma ferramenta essencial que converte os gráficos do jogo de DirectX para Vulkan. Sem ele, os jogos ficam muito mais lentos ou simplesmente não abrem.',
        versoes: {
          'DXVK 1.10.3': 'Jogos antigos (DirectX 9)',
          'DXVK 2.3.1': 'A melhor para começar',
          'DXVK 2.4+': 'Mais novo para jogos modernos'
        },
        dicas: [
          '🔹 Jogo não abre? → Troque a versão do DXVK',
          '🔹 Tela preta? → Mude o driver gráfico',
          '🔹 Sempre prefira versões com "Async"'
        ]
      },

      'winlator vs gamehub': {
        titulo: '🪟 Winlator vs GameHub — Qual Escolher?',
        winlator: [
          '✅ Mais leve e rápido',
          '✅ Mais opções avançadas',
          '❌ Interface mais técnica'
        ],
        gamehub: [
          '✅ Mais fácil de usar',
          '✅ Organiza seus jogos bonitinho',
          '✅ Usa Proton — mais jogos funcionam',
          '❌ Um pouquinho mais pesado'
        ],
        conclusao: 'Comece com GameHub se for iniciante. Use Winlator se quiser mais controle e performance.'
      },

      'melhorar performance': {
        titulo: '⚡ Deixar os Emuladores Mais Rápidos',
        lista: [
          '🔹 Resolução menor — é o que mais ajuda!',
          '🔹 Driver correto: Snapdragon = Turnip, outros = Sistema',
          '🔹 Feche outros apps antes de jogar',
          '🔹 Ative o modo de desempenho do celular',
          '🔹 Não jogue com o celular esquentando'
        ]
      },

      'problemas comuns': {
        titulo: '🔧 Problemas Frequentes e Soluções',
        tela_preta: [
          '✅ Troque o driver gráfico',
          '✅ Mude a versão do DXVK',
          '✅ Reduza a resolução',
          '✅ Reinicie o celular — resolve muita coisa!'
        ],
        lento: [
          '✅ Resolução menor primeiro',
          '✅ Use Turnip se for Snapdragon',
          '✅ Feche tudo que não precisa'
        ]
      }
    }

    for (const [chave, valor] of Object.entries(base)) {
      this.dados.set(chave.toLowerCase(), valor)
    }
    console.log(`🎮 Base carregada com ${this.dados.size} tópicos!`)
  },

  salvar() {
    try {
      fs.writeFileSync(this.arquivo, JSON.stringify(Object.fromEntries(this.dados), null, 2))
      return true
    } catch { return false }
  },

  buscar(pergunta, limite = 3) {
    const resultados = []
    const perguntaNorm = normalizar(pergunta)
    const termos = perguntaNorm.split(/\s+/).filter(t => t.length > 2 && !STOPWORDS.has(t))

    for (const [chave, item] of this.dados) {
      let relevancia = 0
      const chaveNorm = normalizar(chave)
      const textoItem = normalizar(JSON.stringify(item))

      if (chaveNorm === perguntaNorm) relevancia += 100
      else if (chaveNorm.includes(perguntaNorm) || perguntaNorm.includes(chaveNorm)) relevancia += 50

      for (const termo of termos) {
        if (chaveNorm.includes(termo)) relevancia += 15
        if (textoItem.includes(termo)) relevancia += 3
      }

      if (relevancia > 0) {
        resultados.push({ chave, item, relevancia })
      }
    }

    return resultados.sort((a, b) => b.relevancia - a.relevancia).slice(0, limite)
  },

  adicionar(pergunta, resposta) {
    this.dados.set(pergunta.toLowerCase().trim(), {
      custom: true,
      resposta,
      data: new Date().toLocaleString('pt-BR')
    })
    this.salvar()
  },

  contar() { return this.dados.size }
}

// ==========================================
// 💬 PROCESSADOR DE MENSAGENS
// ==========================================
async function processarMensagem(texto) {
  const textoLimpo = texto.trim()
  const textoNorm = normalizar(textoLimpo)

  // 1️⃣ Respostas de conversa natural
  for (const [categoria, mapa] of Object.entries(CONVERSA_NATURAL)) {
    for (const [padrao, resposta] of Object.entries(mapa)) {
      if (textoNorm.includes(normalizar(padrao)) || normalizar(padrao).includes(textoNorm)) {
        return { texto: resposta, imagens: [] }
      }
    }
  }

  // 2️⃣ Busca na base de conhecimento
  const resultados = EmuladorBase.buscar(textoLimpo, 3)
  
  if (resultados.length === 1) {
    const item = resultados[0].item
    const respostaTexto = GeradorResposta.gerar(textoLimpo, item, resultados[0].chave)
    
    // 🖼️ Busca imagem se o usuário pediu ou se o item tem termo de busca
    let imagens = []
    if (GeradorResposta.querImagem(textoLimpo) && item.termoBuscaImagem) {
      imagens = await BuscaImagens.buscar(item.termoBuscaImagem, 1)
    }
    return { texto: respostaTexto, imagens }
  } else if (resultados.length > 1) {
    let resposta = `🔍 Encontrei ${resultados.length} coisas relacionadas a isso:\n\n`
    resultados.forEach((r, i) => {
      const titulo = r.item.titulo || r.chave
      resposta += `${i + 1}. ${titulo}\n`
    })
    resposta += '\nMe diga qual você quer saber mais detalhes! 😊'
    return { texto: resposta, imagens: [] }
  }

  return { texto: GeradorResposta.semResposta(textoLimpo), imagens: [] }
}

// ==========================================
// 🌐 SERVIDOR HTTP
// ==========================================
const PORT = process.env.PORT || 3000
http.createServer((req, res) => {
  if (req.url === '/ping') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({ 
      status: 'online', 
      base: EmuladorBase.contar(),
      versao: '5.0-imagens',
      imagens: process.env.PEXELS_API_KEY ? '✅ ativado' : '❌ desativado'
    }))
  } else {
    res.writeHead(200, { 'Content-Type': 'text/plain' })
    res.end('🎮 EmuladorHelper v5.0 — Busca de Imagens Online!')
  }
}).listen(PORT, () => {
  console.log(`🌐 Servidor rodando na porta ${PORT}`)
  console.log(`🖼️ Busca de imagens: ${process.env.PEXELS_API_KEY ? '✅ ATIVADO' : '❌ DESATIVADO (configure PEXELS_API_KEY)'}`)
  PING_SYSTEM.iniciar()
})

// ==========================================
// 📱 BOT WHATSAPP
// ==========================================
const TRIGGER = (process.env.TRIGGER || '!').toLowerCase()
const PHONE_NUMBER = process.env.PHONE_NUMBER || ''
let codigoGerado = false

function apenasDigitos(texto) {
  return String(texto || '').replace(/\D/g, '')
}

async function iniciarBot() {
  EmuladorBase.carregar()
  console.log(`🧠 Sistema iniciado — ${EmuladorBase.contar()} tópicos carregados!`)

  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    auth: state,
    version,
    logger: pino({ level: 'silent' }),
    browser: ['Ubuntu', 'Chrome', '22.04.4'],
    markOnlineOnConnect: false
  })

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      console.log('✅ CONECTADO COM SUCESSO! 🎮')
      codigoGerado = false
    }

    if (connection === 'close') {
      const codigoErro = lastDisconnect?.error?.output?.statusCode
      console.log(`🔌 Desconectado — código: ${codigoErro}`)
      
      if (codigoErro === DisconnectReason.loggedOut || codigoErro === DisconnectReason.badSession) {
        console.log('🔑 Sessão encerrada — reiniciando...')
        codigoGerado = false
        setTimeout(iniciarBot, 5000)
        return
      }
      if (codigoErro !== DisconnectReason.connectionReplaced) {
        setTimeout(iniciarBot, 5000)
      }
    }

    if (connection === 'connecting' && !sock.authState.creds.registered && !codigoGerado) {
      if (!PHONE_NUMBER) {
        console.error('❌ Configure PHONE_NUMBER no Render! Ex: 5511999999999')
        return
      }
      const telefone = apenasDigitos(PHONE_NUMBER)
      if (telefone.length < 10) {
        console.error(`❌ Número inválido: ${PHONE_NUMBER}`)
        return
      }
      codigoGerado = true
      setTimeout(async () => {
        try {
          const codigo = await sock.requestPairingCode(telefone)
          console.log('\n' + '═'.repeat(55))
          console.log('📲 CÓDIGO DE PAREAMENTO: ' + codigo)
          console.log('👉 Abra WhatsApp → Configurações → Aparelhos Conectados')
          console.log('👉 Conectar com número de telefone → digite o código')
          console.log('═'.repeat(55) + '\n')
        } catch (err) {
          codigoGerado = false
          console.error(`❌ Erro: ${err.message}`)
        }
      }, 3000)
    }
  })

  sock.ev.on('messages.upsert', async (m) => {
    const msg = m.messages[0]
    if (!msg.message || msg.key.fromMe) return

    const texto = msg.message.conversation || msg.message.extendedTextMessage?.text || ''
    const textoLimpo = texto.trim()
    const responder = (resposta) => sock.sendMessage(msg.key.remoteJid, { text: resposta }, { quoted: msg })
    const responderComImagem = async (resposta, imagemUrl, legenda) => {
      if (imagemUrl) {
        try {
          await sock.sendMessage(msg.key.remoteJid, { 
            image: { url: imagemUrl },
            caption: resposta + legenda
          }, { quoted: msg })
        } catch (err) {
          console.warn(`⚠️ Não foi possível enviar imagem: ${err.message}`)
          await responder(resposta + legenda)
        }
      } else {
        await responder(resposta)
      }
    }

    // ⚙️ Comandos
    if (textoLimpo.startsWith(TRIGGER)) {
      const cmd = textoLimpo.slice(TRIGGER.length).trim().toLowerCase()
      const [acao, ...resto] = cmd.split(/\s+/)
      const args = resto.join(' ')

      switch (acao) {
        case 'ajuda':
        case 'comandos':
          await responder(`📋 **Comandos disponíveis:**

!ajuda — Mostra esta mensagem
!ping — Verifica se estou online
!lista — Lista todos os tópicos
!imagem [termo] — Busca uma imagem na internet
!corrige pergunta = resposta — Me ensina algo novo

💡 Também pode perguntar assim:
• "Mostre-me o Winlator"
• "Imagem do Eden Emulator"
• "Como é a interface do GameHub" 😊`)
          break

        case 'ping':
          await responder('🏓 Pong! Estou online e pronto pra te ajudar! 🎮')
          break

        case 'lista':
          const itens = [...EmuladorBase.dados.keys()].slice(0, 30)
          await responder(`📚 **Tópicos que conheço:** ${EmuladorBase.contar()} no total\n\n${itens.map((k, i) => `${i + 1}. ${k}`).join('\n')}\n\nMe pergunte sobre qualquer um! 😊`)
          break

        case 'imagem':
          if (!args) {
            await responder('🖼️ Use assim: !imagem winlator\nOu simplesmente digite: "imagem do Eden"')
            break
          }
          await responder(`🔍 Buscando imagem de "${args}"...`)
          const imagens = await BuscaImagens.buscar(args, 1)
          if (imagens.length > 0) {
            await responderComImagem(
              `✅ Encontrei! 📸`,
              imagens[0].url,
              `\n📸 Foto de ${imagens[0].autor}\n🔗 ${imagens[0].pagina}`
            )
          } else {
            await responder(`😕 Não encontrei imagens para "${args}". Tente outro termo!`)
          }
          break

        case 'corrige':
          if (!args.includes('=')) {
            await responder('📝 Use assim: !corrige sua pergunta = a resposta correta')
            break
          }
          const [perg, resp] = args.split('=').map(s => s.trim())
          if (!perg || !resp) {
            await responder('⚠️ Falta a pergunta ou a resposta! Tente de novo.')
            break
          }
          EmuladorBase.adicionar(perg, resp)
          await responder(`✅ **Salvo com sucesso! 🧠**\n\n📌 Pergunta: ${perg}\n💬 Resposta: ${resp}`)
          break

        default:
          await responder('🤔 Comando não reconhecido. Use !ajuda para ver o que posso fazer.')
      }
      return
    }

    // 💬 Perguntas normais — com suporte a imagens!
    console.log(`💬 Pergunta recebida: ${texto}`)
    await sock.readMessages([msg.key])
    
    const { texto: respostaTexto, imagens } = await processarMensagem(textoLimpo)
    
    if (imagens.length > 0) {
      await responderComImagem(
        respostaTexto,
        imagens[0].url,
        `\n📸 Foto de ${imagens[0].autor}\n🔗 ${imagens[0].pagina}`
      )
    } else {
      await responder(respostaTexto)
    }
  })
}

iniciarBot().catch(err => console.error('❌ Erro ao iniciar:', err))
